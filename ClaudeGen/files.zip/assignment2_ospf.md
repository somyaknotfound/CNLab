# Assignment 2 — Dynamic Routing using OSPF

**Objective:** Configure OSPF so three routers learn routes from each other automatically,
then verify end-to-end connectivity between all four PCs.

Every step tells you what to place, what to click, what to type, and how to verify it worked.

---

## Topology at a glance

```
                         R2
              S0/0/0 .------.  S0/0/1
        10.0.12.0/30 |      | 10.0.23.0/30
                   .-'      '-.
                  /            \
                R1 -----------  R3
             S0/0/1  19.0.13.0/30  S0/0/0
             (the R1-R3 link)
             G0/0              G0/0
       192.168.1.0/24    192.168.3.0/24
             |                  |
            SW1                SW3
          /     \            /      \
        PC1     PC2        PC3      PC4
```

R2 also has a LAN (192.168.2.0/24) hanging off its G0/0 with its own switch/PCs.

### Addressing plan

| Link / LAN | Network | Interface(s) & IP |
|---|---|---|
| R1 <-> R2 (serial) | 10.0.12.0/30 | R1 S0/0/0 = 10.0.12.1 · R2 S0/0/0 = 10.0.12.2 |
| R2 <-> R3 (serial) | 10.0.23.0/30 | R2 S0/0/1 = 10.0.23.2 · R3 S0/0/0 = 10.0.23.3 |
| R1 <-> R3 (serial) | 19.0.13.0/30 | R1 S0/0/1 = 19.0.13.1 · R3 S0/0/1 = 19.0.13.3 |
| R1 LAN | 192.168.1.0/24 | R1 G0/0 = 192.168.1.1 |
| R2 LAN | 192.168.2.0/24 | R2 G0/0 = 192.168.2.1 |
| R3 LAN | 192.168.3.0/24 | R3 G0/0 = 192.168.3.1 |

**/30 refresher:** mask `255.255.255.252`, wildcard `0.0.0.3`, only 2 usable hosts —
perfect for point-to-point router links.

PCs (gateway = their router's G0/0):
| PC | IP | Mask | Gateway |
|---|---|---|---|
| PC1 | 192.168.1.10 | 255.255.255.0 | 192.168.1.1 |
| PC2 | 192.168.1.11 | 255.255.255.0 | 192.168.1.1 |
| PC3 | 192.168.3.10 | 255.255.255.0 | 192.168.3.1 |
| PC4 | 192.168.3.11 | 255.255.255.0 | 192.168.3.1 |

---

## STEP 1 — Place the devices

**Where:** Device palette (bottom-left).

- 3 **Routers** — model **ISR 4321** (or any router with WIC-2T serial support). Rename
  them **R1, R2, R3** (right-click -> Rename).
- 2–3 **2960-24TT switches** (SW1, SW2, SW3) — one per LAN that has PCs.
- **PCs** — PC1, PC2 on the R1 LAN; PC3, PC4 on the R3 LAN (add R2-LAN PCs if required).

> **Serial ports need a module.** Routers don't ship with serial interfaces by default.
> For each router: double-click -> **Physical** tab -> power OFF (click the switch on the
> chassis) -> drag a **WIC-2T** (or NIM-2T on ISR4321) into an empty slot -> power ON.
> Now you'll have S0/0/0 and S0/0/1. Do this on all three routers before cabling.

---

## STEP 2 — Cable everything

**Where:** Connections -> **Automatic** for LAN links; **Serial DCE** for router-to-router.

- **LAN links (copper):** R1 G0/0 -> SW1; SW1 -> PC1, PC2. Same for R3/SW3/PC3,PC4
  (and R2/SW2 if used). Automatic tool is fine here.
- **Serial links (router-to-router):** use the **Serial DCE** cable
  (Connections -> the cable icon that looks like a lightning/serial connector).
  - R1 S0/0/0 <-> R2 S0/0/0
  - R2 S0/0/1 <-> R3 S0/0/0
  - R1 S0/0/1 <-> R3 S0/0/1
  - The end you attach FIRST becomes the **DCE** end and needs a **clock rate**
    (Packet Tracer marks the DCE end with a small clock symbol on the cable).

---

## STEP 3 — Discover interface names

**Where:** Each router -> CLI tab.

```
enable
show ip interface brief
```
Confirm the serial names (S0/0/0, S0/0/1) and the LAN name (G0/0). Substitute whatever
appears in the Interface column into the commands below. All serial/LAN interfaces will
show **administratively down** until you configure and `no shutdown` them.

---

## STEP 4 — Configure R1 interfaces

**Where:** R1 -> CLI tab.

```
enable
configure terminal
hostname R1

interface GigabitEthernet0/0
 ip address 192.168.1.1 255.255.255.0
 no shutdown
exit

interface Serial0/0/0
 ip address 10.0.12.1 255.255.255.252
 clock rate 64000            ! ONLY on the DCE end of the cable
 no shutdown
exit

interface Serial0/0/1
 ip address 19.0.13.1 255.255.255.252
 clock rate 64000            ! ONLY if this end is DCE
 no shutdown
exit
end
write memory
```

> **`clock rate`** is required on the DCE end of every serial link (the end where you
> plugged the cable in first). If both ends are missing it, or it's on the DTE end, the
> line protocol stays **down**. If unsure which end is DCE, set `clock rate 64000` on both
> ends — the DTE end simply ignores it. Harmless.

---

## STEP 5 — Configure R2 interfaces

**Where:** R2 -> CLI tab.

```
enable
configure terminal
hostname R2

interface GigabitEthernet0/0
 ip address 192.168.2.1 255.255.255.0
 no shutdown
exit

interface Serial0/0/0
 ip address 10.0.12.2 255.255.255.252
 no shutdown                ! DTE end here (R1 side was DCE) - no clock rate
exit

interface Serial0/0/1
 ip address 10.0.23.2 255.255.255.252
 clock rate 64000           ! DCE end toward R3
 no shutdown
exit
end
write memory
```

---

## STEP 6 — Configure R3 interfaces

**Where:** R3 -> CLI tab.

```
enable
configure terminal
hostname R3

interface GigabitEthernet0/0
 ip address 192.168.3.1 255.255.255.0
 no shutdown
exit

interface Serial0/0/0
 ip address 10.0.23.3 255.255.255.252
 no shutdown                ! DTE end (R2 was DCE)
exit

interface Serial0/0/1
 ip address 19.0.13.3 255.255.255.252
 no shutdown                ! DTE end (R1 was DCE)
exit
end
write memory
```

After Steps 4–6, verify each serial link is **up/up** before touching OSPF:
```
show ip interface brief
```
If a serial shows `up / down` (line up, protocol down) -> missing/mismatched
`clock rate` on the DCE end. Fix that first; OSPF can't form a neighbor over a down link.

---

## STEP 7 — Enable OSPF on R1

**Where:** R1 -> CLI tab.

OSPF advertises networks with `network <address> <wildcard> area <n>`. The wildcard is the
inverse mask. Put everything in **area 0** (the backbone) for a single-area lab.

```
enable
configure terminal
router ospf 1                 ! process ID (locally significant, 1 is fine)
 network 192.168.1.0 0.0.0.255 area 0     ! R1 LAN
 network 10.0.12.0   0.0.0.3   area 0     ! R1-R2 serial
 network 19.0.13.0   0.0.0.3   area 0     ! R1-R3 serial
exit
end
write memory
```

Wildcard cheat sheet: /24 -> `0.0.0.255`, /30 -> `0.0.0.3`.

---

## STEP 8 — Enable OSPF on R2

```
enable
configure terminal
router ospf 1
 network 192.168.2.0 0.0.0.255 area 0     ! R2 LAN
 network 10.0.12.0   0.0.0.3   area 0     ! R2-R1 serial
 network 10.0.23.0   0.0.0.3   area 0     ! R2-R3 serial
exit
end
write memory
```

As neighbors come up you'll see console messages like:
`%OSPF-5-ADJCHG: Process 1, Nbr 10.0.12.1 on Serial0/0/0 ... LOADING to FULL`
FULL = a working OSPF adjacency. That's what you want.

---

## STEP 9 — Enable OSPF on R3

```
enable
configure terminal
router ospf 1
 network 192.168.3.0 0.0.0.255 area 0     ! R3 LAN
 network 10.0.23.0   0.0.0.3   area 0     ! R3-R2 serial
 network 19.0.13.0   0.0.0.3   area 0     ! R3-R1 serial
exit
end
write memory
```

---

## STEP 10 — Set PC IPs

**Where:** Each PC -> Desktop -> IP Configuration -> Static.

Use the PC table above. Gateway = the local router's G0/0 (192.168.1.1 for PC1/PC2,
192.168.3.1 for PC3/PC4).

---

## STEP 11 — Verify OSPF learned the routes

**Where:** Any router -> CLI tab.

```
show ip ospf neighbor       ! each router should list its directly-connected neighbors, state FULL
show ip route ospf          ! OSPF-learned routes marked with "O"
show ip route               ! full table: C=connected, O=OSPF-learned remote networks
```

On R1 you should see **O** routes for 192.168.2.0, 192.168.3.0, and 10.0.23.0 —
networks R1 is not directly connected to but learned via OSPF. That's the whole point:
you never typed those routes, OSPF discovered them.

---

## STEP 12 — Verify end-to-end (the deliverable)

**Where:** PCs -> Command Prompt.

```
! from PC1 (192.168.1.10)
ping 192.168.1.1     ! own gateway
ping 192.168.2.1     ! R2 LAN gateway (across OSPF)
ping 192.168.3.10    ! PC3 on the far LAN  -> proves full end-to-end routing
tracert 192.168.3.10 ! shows the hop-by-hop path OSPF chose
```

`ping` between all PCs succeeding = OSPF is fully working. `tracert` reveals which path
was taken (OSPF picks lowest total cost; the direct R1-R3 link usually wins over going
through R2).

---

## Troubleshooting (OSPF-specific)

| Symptom | Cause / fix |
|---|---|
| Serial shows `up/down` | Missing/mismatched `clock rate` on the DCE end. Set it on the DCE (or both) ends. |
| No OSPF neighbor forms | Link is down, or the interface's network isn't in a `network ... area` statement, or mismatched area numbers, or mismatched subnet mask on the link. |
| Neighbor stuck in INIT/EXSTART | Duplicate router-id, or MTU mismatch (rare in PT). Check both ends' masks match. |
| Some LANs reachable, others not | A `network` statement is missing on one router. Every connected network must be advertised. |
| Wrong wildcard (used mask instead) | `network 192.168.1.0 255.255.255.0` is wrong — OSPF wants the WILDCARD `0.0.0.255`. |
| Ping to far LAN fails, routers ping fine | PC gateway wrong, or the far LAN network not advertised in OSPF. |
| Everything works then breaks on reload | Never saved. `write memory` on all three routers. |

---

## Key concepts to remember

- **OSPF is dynamic** — you advertise your *connected* networks, and routers exchange
  them automatically. Contrast with static routing where you hand-type every remote route.
- **`network <addr> <wildcard> area <n>`** does two jobs: it tells OSPF which interfaces
  to run on AND which networks to advertise. The wildcard is the inverse of the subnet mask.
- **Area 0** is the backbone; single-area labs put everything in area 0.
- **Process ID** (`router ospf 1`) is local to the router — it does NOT need to match
  between routers (unlike EIGRP's AS number).
- **`clock rate`** on serial DCE is a physical-layer requirement, unrelated to OSPF, but
  it must be right or OSPF has no link to run over.
- Adjacency reaching **FULL** state = success.
